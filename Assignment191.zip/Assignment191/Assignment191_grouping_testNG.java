package NGTest;

import org.testng.annotations.Test;

public class Assignment191_grouping_testNG {
	@Test(groups= {"smoke"})
	public void Testcase1()
	{
		
	}
	@Test(groups= {"system"})
	public void Testcase2()
	{
		
	}
	@Test(groups= {"smoke"})
	public void Testcase3()
	{
		
	}
	@Test(groups= {"system","smoke"})
	public void Testcase4()
	{
		
	}
	@Test(groups= {"smoke"})
	public void Testcase5()
	{
		
	}

}
